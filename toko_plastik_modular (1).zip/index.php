<?php include 'header.php'; ?>
<main>
    <h2>Selamat datang di Tunas Mustika</h2>
    <p>Toko plastik terpercaya untuk kebutuhan harian Anda.</p>
</main>
<?php include 'footer.php'; ?>
