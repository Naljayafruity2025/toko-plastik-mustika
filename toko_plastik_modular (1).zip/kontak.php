<?php include 'header.php'; ?>
<main>
    <h2>Hubungi Kami</h2>
    <p>Alamat: Jl. Gajah Mada No III C, G. Pangilun</p>
    <p>Telepon: 0812-6203-1141</p>
</main>
<?php include 'footer.php'; ?>
