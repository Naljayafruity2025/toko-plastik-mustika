<?php include 'header.php'; ?>
<main>
    <h2>Produk Kami</h2>
    <ul>
        <li>Kantong Plastik HD - Rp 15.000</li>
        <li>Gelas Plastik - Rp 5.000</li>
        <li>Botol Plastik - Rp 8.000</li>
        <li>Wadah Makanan - Rp 25.000</li>
    </ul>
</main>
<?php include 'footer.php'; ?>
