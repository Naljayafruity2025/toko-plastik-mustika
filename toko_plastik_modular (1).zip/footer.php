<?php
echo <<<HTML
<footer>
    <p>&copy; 2025 Tunas Mustika. All rights reserved.</p>
</footer>
</body>
</html>
HTML;
?>
