<?php
echo <<<HTML
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tunas Mustika - Toko Plastik</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
    <h1>Tunas Mustika</h1>
    <nav>
        <a href="index.php">Beranda</a>
        <a href="produk.php">Produk</a>
        <a href="kontak.php">Kontak</a>
    </nav>
</header>
HTML;
?>
